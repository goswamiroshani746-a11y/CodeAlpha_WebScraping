# CodeAlpha Web Scraping Project

This project uses Python BeautifulSoup to scrape quotes data from a website.

## Tools Used
- Python
- BeautifulSoup
- Pandas
- Requests

## Output
The scraped data is stored in CSV format.

## How to Run
1. Install required libraries:
   pip install requests beautifulsoup4 pandas

2. Run the script:
   python scraper.py
